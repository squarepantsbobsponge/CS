# 任务:

贡献者：@squarepantsbobsponge @cakerdsp

完成仿真多无人机飞行。

在仿真中启动多架无人机（使用roslaunch），并通过代码控制无人机飞行轨迹。

一个简单的示例如下：

![1732889767228](image/Assignment/1732889767228.png)

启动无人机仿真命令：

要求：对飞行轨迹不做要求，自定义飞行轨迹

要求一段代码控制多架无人机起飞

参考：

使用如下命令来启动多无人机：

```
roslaunch px4 multi_uav_mavros_sitl.launch
```

但是一般初次运行会报错，一般是没有配置环境变量，可以参考下面的文章进行配置：

[参考文章](https://blog.csdn.net/f1ang_/article/details/129418234)

注意，PX4版本不同，sitl_gazebo和setup_gazebo.bash在源码中的路径会有变化，一般来说v13版本的是可以直接使用参考文章中的，v14及以后是如下命令：

```
source Tools/simulation/gazebo-classic/setup_gazebo.bash $(pwd) $(pwd)/build/px4_sitl_default
export ROS_PACKAGE_PATH=$ROS_PACKAGE_PATH:$(pwd):$(pwd)/Tools/simulation/gazebo-classic
```

代码可以写成死命令，不过最好写成一般性的代码，易于修改和维护。
